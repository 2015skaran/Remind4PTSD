/*
 * Copyright 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.slidingtabscolors;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Simple Fragment used to display some meaningful content for each page in the sample's
 * {@link android.support.v4.view.ViewPager}.
 */
public class ContentFragment extends Fragment {

    private static final String KEY_TITLE = " ";
    private static final String KEY_INDICATOR_COLOR = "indicator_color";
    private static final String KEY_DIVIDER_COLOR = "divider_color";

    /**
     * @return a new instance of {@link ContentFragment}, adding the parameters into a bundle and
     * setting them as arguments.
     */
    public static ContentFragment newInstance(CharSequence title, int indicatorColor,
            int dividerColor) {

        Bundle bundle = new Bundle();
        bundle.putCharSequence(KEY_TITLE, title);
        bundle.putInt(KEY_INDICATOR_COLOR, indicatorColor);
        bundle.putInt(KEY_DIVIDER_COLOR, dividerColor);

        ContentFragment fragment = new ContentFragment();
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        return inflater.inflate(R.layout.pager_item, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        Bundle args = getArguments();

        if (args != null) {

            HttpClient httpclient = new DefaultHttpClient();
            HttpGet httpget= new HttpGet("http://remindmeptsd.mybluemix.net/daysofsupply");
            String resp= "";
            try {
                HttpResponse response = httpclient.execute(httpget);
                resp = EntityUtils.toString(response.getEntity());
            } catch (ClientProtocolException e) {
                // TODO Auto-generated catch block
            } catch (IOException e) {
                // TODO Auto-generated catch block
            }
            JSONArray arr = null;
            try {
                arr = new JSONArray(resp);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            int responseLength= arr.length();

            String tablerow= "";
            Log.d("success", "jsonresp = " + arr.toString());
            String daysOfSupply;
//            Log.d("login activity", "json[1]=" + arr.getJSONObject(1).getString("name"));
//            Log.d("login activity", "json[1]=" + arr.getJSONObject(1).getString("modified_date"));
//
//            Log.d("login activity", "length = " + arr.length());


            TextView title = (TextView) view.findViewById(R.id.item_title);

            Log.e("title", args.getCharSequence(KEY_TITLE) + "\n");
            if (args.getCharSequence(KEY_TITLE).equals("Med. Status"))
            title.setText("Your Medication(s):Lorazepam \n" +
                    " Days Left to Refill: 10 ");
            else if (args.getCharSequence(KEY_TITLE).equals("Medicine Info"));
            title.setText("Your Medication(s):Lorazepam \n" +
                    " Dosage: 1 tablet/ 8 HOURS PRN ");
            else if (args.getCharSequence(KEY_TITLE).equals("Diagnostic Results"));
            title.setText("Lab Results from 03/04/15 \n" +
                    " Lab Results from 04/05/15 \n Lab Results from 06/03/15 ");
            else
            title.setText("Your Medication(s):Lorazepam \n" +
                    " Days Left to Refill: 10 ");

            title.setText("Hey");
            int indicatorColor = args.getInt(KEY_INDICATOR_COLOR);
            //TextView indicatorColorView = (TextView) view.findViewById(R.id.item_indicator_color);
            int dividerColor = args.getInt(KEY_DIVIDER_COLOR);
            //TextView dividerColorView = (TextView) view.findViewById(R.id.item_divider_color);
           // dividerColorView.setText("Divider: #" + Integer.toHexString(dividerColor));
           // dividerColorView.setTextColor(dividerColor);
        }
    }
}
